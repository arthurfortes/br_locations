`br_locations`` - Cities and States of Brazil Python Lib (IBGE Info)
#######################################################


Description
***********

Cities and States of Brazil Python Lib  based on IBGE Info.


Requirements
************

::

    Python 3


Install:
########

::

    pip install br_locations


Usage
#####

>>> from br_locations.base import br_locale_info



:Authors:
    Arthur Fortes

:Version: 0.0.0 of 10/2022
